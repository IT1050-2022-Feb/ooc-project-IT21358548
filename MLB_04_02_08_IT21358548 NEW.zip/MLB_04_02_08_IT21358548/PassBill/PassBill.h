#pragma once

#include<string>
using namespace std;

class PassBill
{
private:

	int AccountNumber;
	int BillNumber;
	char PastUsage;
	int CustomerID;
	int PastBillDate;
	double PastDiscount;
	double PastDeficitMoney;
	int PastPaymentDate;
public:
	PassBill();
	PassBill(int pAccountNumber, int pBillNumber, char pPastUsage, int pCustomerID, int pPastBillDate, double pPastDiscount, double pPastDeficitMoney, int pPastPaymentDate);
	void ViewPassBill();
	~PassBill();
};
