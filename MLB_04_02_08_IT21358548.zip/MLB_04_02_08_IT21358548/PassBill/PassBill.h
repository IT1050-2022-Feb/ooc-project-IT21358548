class PastBill
{
private:

	char AccountNumber[30];
	char BillNumber[30];
	double PastUsage;
	int CustomerID;
	char PastBillDate;
	double PastDiscount;
	double PastDeficitMoney;
	char PastPaymentDate[30];
public:
	PastBill();
	PastBill(const char pAccountNumber, const char pBillNumber[], double pPastUsage[], int pCustomerID, char pPastBillDate[], double pPastDiscount, double pPastDeficitMoney, char pPastPaymentDate[]);
	void ViewPastBill();
	~PastBill();
};