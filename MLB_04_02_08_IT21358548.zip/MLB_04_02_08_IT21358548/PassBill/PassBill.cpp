#include "stdafx.h"
#include "PassBill.h"
#include<iostream>
using namespace std;

PassBill::PassBill()
{
	cout << "Default Constructor PassBill() called" << endl;
}
PassBill::PassBill(int pAccountNumber, int pBillNumber, char pPastUsage, int pCustomerID, int pPastBillDate, double pPastDiscount, double pPastDeficitMoney, int pPastPaymentDate)
{
	AccountNumber = pAccountNumber;
	BillNumber = pBillNumber;
	PastUsage = pPastUsage;
	CustomerID = pCustomerID;
	PastBillDate = pPastBillDate;
	PastDiscount = pPastDiscount;
	PastDeficitMoney = pPastDeficitMoney;
	PastPaymentDate = pPastPaymentDate;
}
void PassBill::ViewPassBill()
{
}
PassBill::~PassBill() 
{
	cout << "Destructed" << endl;
}