#include "PastBill.h"
#include<iostream>
#include<cstring>
using namespace std;

PastBill::PastBill()
{
	cout << "Default Constructor PastBill() called" << endl;
}
PastBill::PastBill(const char pAccountNumber[], const char pBillNumber[], double pPastUsage, int pCustomerID, const char pPastBillDate[], double pPastDiscount, double pPastDeficitMoney, const char pPastPaymentDate[])
{
	strcpy(AccountNumber, pAccountNumber);
	strcpy(BillNumber, pBillNumber);
	PastUsage = pPastUsage;
	CustomerID = pCustomerID;
	strcpy(PastBillDate, pPastBillDate);
	PastDiscount = pPastDiscount;
	PastDeficitMoney = pPastDeficitMoney;
	strcpy(PastPaymentDate, pPastPaymentDate);
}

void PastBill::ViewPastBill()
{
}
PastBill::~PastBill()
{
	cout << "Destructed" << endl;
}

