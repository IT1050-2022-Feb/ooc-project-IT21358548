#pragma once

#include<string>
using namespace std;

class Register
{
private:

	string email;
	string password;
public:
	Register();
	Register(string pemail, string ppassword);
	void login();
	void Bill();
	void Reminder();
	void Payment();
	void display();
	~Register();
};