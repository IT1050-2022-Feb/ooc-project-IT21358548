#include "stdafx.h"
#include "Register.h"
#include<iostream>
using namespace std;


Register::Register()
{
	cout << "Default constructor of register custmer" << endl;
}

Register::Register(string pemail, string ppassword)
{

	email = pemail;
	password = ppassword;
}

void Register::login()
{
}

void Register::Bill()
{
}

void Register::Reminder()
{
}

void Register::Payment()
{
}



void Register::display()
{

	cout << "Register Customer Email :" << email << endl;
	cout << "Register Customer Password :" << password << endl;
	cout << endl;
}


Register::~Register()
{
	//cout << "Destructed" << endl;
}
